import cloudmusic as cm
from selenium import webdriver
from bs4 import BeautifulSoup
import time
import pprint
from Spiders import Connect_Mysql as CM


def chargeSex(n):
    if n == '1':
        return '男'
    return '女'


Gedan_id_list = ['2829816518','5316433881','5288393759','2829816518','5434513615']

for Gedan_id in Gedan_id_list: 
    # Gedan_id = Gedan_id_list[0]
    path = 'E:/Chrome Don/chromedriver'
    url = 'https://music.163.com/#/playlist?id='+Gedan_id

    headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36'}
    driver = webdriver.Chrome(path)

    driver.get(url)
    driver.implicitly_wait(1)

    iframe = driver.find_elements_by_tag_name('iframe')[0]
    driver.switch_to.frame(iframe)
    soup = BeautifulSoup(driver.page_source,'lxml')

    Gedan_type_list = soup.find_all('a',class_='u-tag')#每个元素的text便是标签

    # Gedan_type = ','.join(Gedan_type_list)

    Gedan_type = ''

    for x in Gedan_type_list:
        Gedan_type = Gedan_type + x.text +'.'


    Gedan_play_times = soup.find_all('strong')[0].text
    print(Gedan_id,Gedan_type,Gedan_play_times,url)

    #---------------------------------------------------------------
    music_list = cm.getPlaylist(Gedan_id_list[0])#这是歌单的id

    for music in music_list:
        music_name = music.name
        music_Commentsnum = music.getCommentsCount()
        # print(music.getHotComments()[0]['content'])

        print(music.id,music_name,music.artist)
        if(len(music.getHotComments()) > 0):
            print(music.getHotComments()[0]['content'])
            print(music.getHotComments()[0]['likeCount'])
            print(music.getHotComments()[0]['userId'])

            user_id = cm.getUser(music.getHotComments()[0]['userId'])
            print(user_id.nickname,chargeSex(user_id.sex),user_id.fans)
        print('------------------------------------')
    driver.close()