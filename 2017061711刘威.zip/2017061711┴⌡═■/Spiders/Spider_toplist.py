from nltk.corpus.reader import xpath
from selenium import webdriver
from bs4 import BeautifulSoup
import time

def kill_kuohao(str):
    str = str.replace('(','').replace(')','')

    return  str

path = 'E:/Chrome Don/chromedriver'
url = 'https://music.163.com/#/discover/toplist'
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36'}
driver = webdriver.Chrome(path)
driver.get(url)
driver.implicitly_wait(1)
# driver.switch_to.frame('g_frame')
# 如果报错missing value值，则将Chrome与Chromedriver更新到最新

soup = BeautifulSoup(driver.page_source, 'lxml')
title = soup.title.string

#iframe 嵌套
iframe = driver.find_elements_by_tag_name('iframe')[0]
driver.switch_to.frame(iframe)


# driver2 = webdriver.PhantomJS()

soup = BeautifulSoup(driver.page_source,'lxml')



collect_num = soup.find_all('div',class_='btns f-cb')[0].find_all('i')[1].text
collect_num = kill_kuohao(collect_num)

share_num = soup.find_all('div',class_='btns f-cb')[0].find_all('i')[2].text
share_num = kill_kuohao(share_num)

comment_num = soup.find_all('div',class_='btns f-cb')[0].find_all('i')[4].text
comment_num = kill_kuohao(comment_num)

print('收藏={},fengixang={},pinglun={}'.format(collect_num,share_num,comment_num))

# mysoup = soup.find_all('tr')
# for x in range(1,len(mysoup)):
#     Songname = mysoup[x].find('b').get('title')
#     Songer = mysoup[x].find_all('td')[3].find('div').get('title')
#     print(Songer)
#
#     print("-----------------------")
