import pymysql

conn = pymysql.connect(host="localhost", user="root", password="****", database="couldmusic", port=3306,charset='utf8mb4')
# cursor = conn.cursor()
# insert = "insert into tryconnect(id) VALUES (%s)"
# res = "333"
# cursor.execute(insert,res)
# conn.commit()

