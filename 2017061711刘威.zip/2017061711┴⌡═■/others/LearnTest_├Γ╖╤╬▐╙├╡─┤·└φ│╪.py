import requests
import parsel
from bs4 import BeautifulSoup
url = 'https://www.kuaidaili.com/free/inha/1/'
headers = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.190 Safari/537.36'}
# soup = BeautifulSoup(requests.get(url,headers = headers).text,'lxml')
html_data = requests.get(url,headers = headers).text
select = parsel.Selector(html_data)

trs = select.xpath('//table[@class="table table-bordered table-striped"]/tbody/tr')
procexs = []
for tr in trs:
    ip = tr.xpath('./td[@data-title="IP"]/text()').get()
    port = tr.xpath('./td[@data-title="PORT"]/text()').get()
    # print("ip={},port = {}".format(ip,port))

    ip_procex = ip + ":" + port
    ip_dict = {
        'http':"http://"+ ip_procex,
        'https':"https://"+ ip_procex,
    }
    procexs.append(ip_procex)